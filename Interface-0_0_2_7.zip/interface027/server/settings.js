/* Preferências persistentes da Interface (0.0.2.7).
   Arquivo único e por usuário: ~/.config/interface-linux-desktop/settings.json (ou $INTERFACE_CONFIG_DIR).
   - Esquema validado: valor inválido nunca chega ao disco (cai no valor anterior).
   - Escrita atômica (arquivo temporário + rename) e serializada (uma gravação por vez).
   - Arquivo corrompido não derruba nada: é movido para settings.json.corrupt-<data> e as predefinições voltam.
   - Papel de parede personalizado: a imagem é copiada para <config>/wallpapers (antes só existia como blob na sessão).
   Não altera nenhuma configuração global do sistema (GNOME/KDE/XFCE). */
import path from 'node:path';
import os from 'node:os';
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import express from 'express';

export const WINDOW_IDS = ['terminal', 'settings', 'monitor', 'files'];
const BOOL_INTERFACE = ['animations', 'dynamicDock', 'notifications', 'desktopIcons', 'visualEffects'];
const WALLPAPER_FILE = /^custom-[0-9a-f]{16}\.(png|jpg|webp|gif)$/;
const MAX_WALLPAPER = 15 * 1024 * 1024;

export const DEFAULTS = Object.freeze({
  version: 1,
  appearance: {theme: 'dark', wallpaper: 'padrao', customWallpaper: null},
  interface: {animations: true, dynamicDock: true, notifications: true, desktopIcons: true, visualEffects: true, fileManager: 'native'},
  windows: {rememberGeometry: true, restoreOpen: false, geometry: {}, open: []},
  files: {lastPath: null, showHidden: false},
  dock: {apps: []},
});
const clone = v => JSON.parse(JSON.stringify(v));

/* ---------- Validação ---------- */
const isObj = v => v && typeof v === 'object' && !Array.isArray(v);
const bool = (v, fb) => typeof v === 'boolean' ? v : fb;
const num = (v, lo, hi) => Number.isFinite(v) ? Math.round(Math.min(hi, Math.max(lo, v))) : null;
const cleanStr = (v, max) => typeof v === 'string' && v.length <= max && !/[\0\r\n]/.test(v) ? v : null;

function cleanGeometry(raw, fb) {
  const out = {};
  for (const id of WINDOW_IDS) {
    const g = raw?.[id]; if (!isObj(g)) continue; /* ausente = removida (patch com null) */
    const x = num(g.x, -4000, 20000), y = num(g.y, -4000, 20000), w = num(g.w, 200, 10000), h = num(g.h, 120, 10000);
    if ([x, y, w, h].some(n => n === null)) { if (fb?.[id]) out[id] = fb[id]; continue; }
    out[id] = {x, y, w, h, max: g.max === true};
  }
  return out;
}
const cleanDock = (raw, fb) => !Array.isArray(raw) ? fb : raw.filter(a => isObj(a) && ['desktop', 'flatpak', 'snap'].includes(a.kind)
  && typeof a.id === 'string' && /^[\w.+@-]{1,160}$/.test(a.id) && typeof a.name === 'string')
  .slice(-12).map(a => ({kind: a.kind, id: a.id, name: a.name.replace(/[\0\r\n]/g, ' ').slice(0, 80)}));

/* raw (qualquer coisa) → objeto completo e válido. Campos inválidos herdam o valor de `fb` (o estado atual ou as predefinições). */
export function sanitize(raw, fb = DEFAULTS) {
  const r = isObj(raw) ? raw : {};
  const a = isObj(r.appearance) ? r.appearance : {}, i = isObj(r.interface) ? r.interface : {}, w = isObj(r.windows) ? r.windows : {};
  const f = isObj(r.files) ? r.files : {}, d = isObj(r.dock) ? r.dock : {};
  const out = clone(DEFAULTS);

  out.appearance.theme = ['dark', 'light'].includes(a.theme) ? a.theme : fb.appearance.theme;
  const cw = a.customWallpaper === null ? null : isObj(a.customWallpaper) && WALLPAPER_FILE.test(a.customWallpaper.file || '')
    ? {file: a.customWallpaper.file, name: cleanStr(a.customWallpaper.name, 120) || 'imagem'} : undefined;
  out.appearance.customWallpaper = cw === undefined ? fb.appearance.customWallpaper : cw;
  const wp = typeof a.wallpaper === 'string' && /^[a-z0-9-]{1,40}$/.test(a.wallpaper) ? a.wallpaper : fb.appearance.wallpaper;
  out.appearance.wallpaper = wp === 'custom' && !out.appearance.customWallpaper ? 'padrao' : wp;

  for (const k of BOOL_INTERFACE) out.interface[k] = bool(i[k], fb.interface[k]);
  out.interface.fileManager = ['native', 'embedded'].includes(i.fileManager) ? i.fileManager : fb.interface.fileManager;

  out.windows.rememberGeometry = bool(w.rememberGeometry, fb.windows.rememberGeometry);
  out.windows.restoreOpen = bool(w.restoreOpen, fb.windows.restoreOpen);
  out.windows.geometry = cleanGeometry(w.geometry, fb.windows.geometry);
  out.windows.open = Array.isArray(w.open) ? [...new Set(w.open.filter(x => WINDOW_IDS.includes(x)))] : fb.windows.open;

  out.files.lastPath = f.lastPath === null ? null : cleanStr(f.lastPath, 4096) !== null ? f.lastPath : fb.files.lastPath;
  out.files.showHidden = bool(f.showHidden, fb.files.showHidden);

  out.dock.apps = cleanDock(d.apps, fb.dock.apps);
  return out;
}

/* Aplica um patch parcial ao estado atual. Grupos são mesclados campo a campo; geometry é mesclado por janela (null remove);
   listas (open, dock.apps) são substituídas. */
export function applyPatch(current, patch) {
  const next = clone(current);
  if (!isObj(patch)) return next;
  for (const group of ['appearance', 'interface', 'windows', 'files', 'dock']) {
    if (!isObj(patch[group])) continue;
    for (const [k, v] of Object.entries(patch[group])) {
      if (group === 'windows' && k === 'geometry' && isObj(v)) {
        for (const [id, g] of Object.entries(v)) { if (g === null) delete next.windows.geometry[id]; else next.windows.geometry[id] = g; }
      } else next[group][k] = v;
    }
  }
  return sanitize(next, current);
}

/* Compatibilidade com a 0.0.2.6: o arquivo era um objeto plano com os cinco booleanos. */
function migrateLegacy(raw) {
  if (!isObj(raw) || raw.version || !BOOL_INTERFACE.some(k => k in raw)) return raw;
  return {interface: Object.fromEntries(BOOL_INTERFACE.filter(k => k in raw).map(k => [k, raw[k]]))};
}
/* Tolera o "\n" literal que a 0.0.2.6 gravava no fim do arquivo. */
const parseLenient = text => JSON.parse(text.replace(/(?:\\n|\s)+$/, ''));

/* ---------- Armazenamento ---------- */
export function createStore(dir = process.env.INTERFACE_CONFIG_DIR || path.join(os.homedir(), '.config', 'interface-linux-desktop')) {
  const file = path.join(dir, 'settings.json'), wpDir = path.join(dir, 'wallpapers');
  let cache = null, mtime = -1, warning = null, chain = Promise.resolve();

  async function load() {
    let st = null; try { st = await fs.stat(file); } catch {}
    if (cache && ((!st && mtime === 0) || (st && st.mtimeMs === mtime))) return cache;
    if (!st) { cache = clone(DEFAULTS); mtime = 0; return cache; }
    try {
      const raw = migrateLegacy(parseLenient(await fs.readFile(file, 'utf8')));
      cache = sanitize(raw); mtime = st.mtimeMs; warning = null;
    } catch (e) {
      const bak = `${file}.corrupt-${new Date().toISOString().replace(/[:.]/g, '-')}`;
      try { await fs.rename(file, bak); warning = `settings.json estava corrompido e foi movido para ${path.basename(bak)}. As predefinições foram restauradas.`; }
      catch { warning = 'settings.json está ilegível; usando as predefinições.'; }
      cache = clone(DEFAULTS); mtime = 0;
      const old = (await fs.readdir(dir).catch(() => [])).filter(n => n.startsWith('settings.json.corrupt-')).sort();
      for (const n of old.slice(0, -3)) await fs.rm(path.join(dir, n), {force: true}).catch(() => {}); /* guarda só as 3 últimas cópias */
    }
    return cache;
  }
  async function persist(value) {
    await fs.mkdir(dir, {recursive: true, mode: 0o700});
    const tmp = `${file}.tmp-${process.pid}-${Date.now()}`;
    try {
      await fs.writeFile(tmp, JSON.stringify(value, null, 2) + '\n', {mode: 0o600});
      await fs.rename(tmp, file);
    } catch (e) { await fs.rm(tmp, {force: true}).catch(() => {}); throw e; }
    cache = value; mtime = (await fs.stat(file)).mtimeMs;
  }
  async function prune(keep) { /* remove imagens personalizadas que não são mais usadas */
    for (const n of await fs.readdir(wpDir).catch(() => [])) if (WALLPAPER_FILE.test(n) && n !== keep) await fs.rm(path.join(wpDir, n), {force: true}).catch(() => {});
  }
  const serial = fn => { const run = chain.then(fn, fn); chain = run.catch(() => {}); return run; };

  return {
    file, wpDir,
    async get() { const settings = await load(); return {settings: clone(settings), meta: {path: file, exists: mtime > 0, warning}}; },
    patch: patch => serial(async () => {
      const next = applyPatch(await load(), patch); await persist(next);
      await prune(next.appearance.customWallpaper?.file); return clone(next);
    }),
    reset: () => serial(async () => { await fs.rm(file, {force: true}); await prune(null); cache = clone(DEFAULTS); mtime = 0; warning = null; return clone(DEFAULTS); }),
    async setWallpaper(buf, name) {
      const ext = imageExt(buf); if (!ext) throw Object.assign(new Error('Formato de imagem não suportado (use PNG, JPEG, WebP ou GIF).'), {status: 415});
      const fileName = `custom-${crypto.createHash('sha256').update(buf).digest('hex').slice(0, 16)}.${ext}`;
      await fs.mkdir(wpDir, {recursive: true, mode: 0o700});
      await fs.writeFile(path.join(wpDir, fileName), buf, {mode: 0o600});
      return this.patch({appearance: {customWallpaper: {file: fileName, name}, wallpaper: 'custom'}});
    },
  };
}

/* Reconhece o tipo pelos bytes iniciais (não confia no Content-Type nem na extensão). */
export function imageExt(b) {
  if (!Buffer.isBuffer(b) || b.length < 12) return null;
  if (b[0] === 0x89 && b.toString('latin1', 1, 4) === 'PNG') return 'png';
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpg';
  if (b.toString('latin1', 0, 4) === 'GIF8') return 'gif';
  if (b.toString('latin1', 0, 4) === 'RIFF' && b.toString('latin1', 8, 12) === 'WEBP') return 'webp';
  return null;
}

/* ---------- Rotas ---------- */
export function registerSettingsRoutes(app, store = createStore()) {
  const wrap = fn => async (req, res) => { try { await fn(req, res); } catch (e) {
    res.status(e.status || 500).json({error: e.status === 415 ? 'unsupported_media' : 'settings_error', message: e.message}); } };

  app.get('/api/settings', wrap(async (_req, res) => res.json(await store.get())));
  app.patch('/api/settings', wrap(async (req, res) => {
    if (!isObj(req.body)) return res.status(400).json({error: 'bad_request', message: 'Envie um objeto JSON.'});
    res.json({ok: true, settings: await store.patch(req.body)});
  }));
  app.post('/api/settings/reset', wrap(async (_req, res) => res.json({ok: true, settings: await store.reset()})));

  /* Compatibilidade 0.0.2.6: só o grupo "interface", plano. */
  app.get('/api/interface-settings', wrap(async (_req, res) => res.json((await store.get()).settings.interface)));
  app.post('/api/interface-settings', wrap(async (req, res) => res.json({ok: true, settings: (await store.patch({interface: req.body || {}})).interface})));

  /* Papel de parede personalizado: corpo = bytes da imagem; nome original em X-File-Name (URL-encoded). */
  app.post('/api/wallpaper', express.raw({type: () => true, limit: MAX_WALLPAPER}), wrap(async (req, res) => {
    let name = 'imagem'; try { name = decodeURIComponent(String(req.headers['x-file-name'] || '')).replace(/[\0\r\n]/g, ' ').slice(0, 120) || name; } catch {}
    res.json({ok: true, settings: await store.setWallpaper(req.body, name)});
  }));
  app.get('/api/wallpaper/:file', (req, res) => {
    if (!WALLPAPER_FILE.test(req.params.file)) return res.status(404).end();
    res.setHeader('Cache-Control', 'public, max-age=31536000, immutable'); /* o nome contém o hash do conteúdo */
    res.setHeader('Content-Security-Policy', "default-src 'none'; sandbox");
    res.sendFile(req.params.file, {root: store.wpDir}, err => { if (err && !res.headersSent) res.status(404).end(); });
  });
}
