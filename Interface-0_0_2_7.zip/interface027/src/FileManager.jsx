import {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {Folder, FolderPlus, FilePlus, FileText, Image as ImageIcon, Music, Video, Trash2, Copy, Scissors, ClipboardPaste, Pencil, RefreshCw, ArrowLeft, ArrowRight, ArrowUp,
  Home, Monitor, Download, HardDrive, Eye, EyeOff, ExternalLink, Check, AlertCircle, Link2} from 'lucide-react';
import {api, post, formatBytes} from './utils';
import {useSettings, patchSettings} from './settings';

/* Gerenciador de Arquivos embutido (0.0.2.7). Fala com /api/files/* (server/files.js).
   O Nautilus nativo continua sendo o padrão da Interface; esta janela é a versão leve, integrada e persistente. */

const PLACE_ICON = {home: Home, desktop: Monitor, documents: FileText, downloads: Download, music: Music, pictures: ImageIcon, videos: Video, trash: Trash2, root: HardDrive};
const IMG = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.bmp']), AUD = new Set(['.mp3', '.ogg', '.wav', '.flac', '.m4a', '.opus']), VID = new Set(['.mp4', '.mkv', '.webm', '.avi', '.mov']);
const iconFor = e => e.type === 'dir' ? Folder : IMG.has(e.ext) ? ImageIcon : AUD.has(e.ext) ? Music : VID.has(e.ext) ? Video : FileText;
const join = (dir, name) => (dir === '/' ? '' : dir) + '/' + name;
const fmtDate = ms => ms ? new Date(ms).toLocaleString('pt-BR', {dateStyle: 'short', timeStyle: 'short'}) : '—';
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

export default function FileManager({notify}) {
  const {settings} = useSettings();
  const showHidden = settings.files.showHidden;
  const [places, setPlaces] = useState([]);
  const [data, setData] = useState(null);                  /* {path, parent, entries, total, truncated} */
  const [pathInput, setPathInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [hist, setHist] = useState({stack: [], idx: -1});
  const [sel, setSel] = useState(() => new Set());
  const [clip, setClip] = useState(null);                  /* {mode: 'copy'|'move', paths: [...]} */
  const [dialog, setDialog] = useState(null);              /* {kind: 'mkdir'|'create'|'rename'|'trash', value, error} */
  const [menu, setMenu] = useState(null);                  /* {x, y} dentro da janela */
  const [status, setStatus] = useState(null);              /* {ok, text} */
  const [busy, setBusy] = useState(false);
  const rootRef = useRef(null), anchor = useRef(null), req = useRef(0), alive = useRef(true), hiddenRef = useRef(showHidden);
  hiddenRef.current = showHidden;
  useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);

  const entries = data?.entries || [];
  const cwd = data?.path || '';
  const selected = useMemo(() => entries.filter(e => sel.has(e.name)), [entries, sel]);
  const selPaths = selected.map(e => join(cwd, e.name));
  const say = (text, ok = true) => setStatus({ok, text});

  /* ---------- Navegação ---------- */
  const load = useCallback(async (path, {push = true, keepSel = false, fallback = false} = {}) => {
    const id = ++req.current; setLoading(true); setError('');
    try {
      const d = await api(`/api/files/list?path=${encodeURIComponent(path)}&hidden=${hiddenRef.current ? 1 : 0}`);
      if (!alive.current || id !== req.current) return;
      setData(d); setPathInput(d.path); setLoading(false); setMenu(null);
      if (!keepSel) { setSel(new Set()); anchor.current = null; }
      if (push) setHist(h => h.stack[h.idx] === d.path ? h : {stack: [...h.stack.slice(0, h.idx + 1), d.path], idx: h.idx + 1});
      patchSettings({files: {lastPath: d.path}});
    } catch (e) {
      if (!alive.current || id !== req.current) return;
      setLoading(false);
      if (fallback) return load('~', {fallback: false}); /* a última pasta salva não existe mais */
      setError(e.message); setPathInput(cwd);
    }
  }, [cwd]);
  useEffect(() => { api('/api/files/places').then(d => alive.current && setPlaces(d.places || [])).catch(() => {}); load(settings.files.lastPath || '~', {fallback: true}); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const reload = useCallback((keepSel = true) => cwd ? load(cwd, {push: false, keepSel}) : load('~'), [cwd, load]);
  const go = path => load(path);
  const back = () => { if (hist.idx > 0) { setHist(h => ({...h, idx: h.idx - 1})); load(hist.stack[hist.idx - 1], {push: false}); } };
  const forward = () => { if (hist.idx < hist.stack.length - 1) { setHist(h => ({...h, idx: h.idx + 1})); load(hist.stack[hist.idx + 1], {push: false}); } };
  const up = () => data?.parent && go(data.parent);
  const toggleHidden = () => { patchSettings({files: {showHidden: !showHidden}}); hiddenRef.current = !showHidden; if (cwd) load(cwd, {push: false, keepSel: true}); };

  /* ---------- Ações ---------- */
  const run = async (fn, okText) => {
    setBusy(true); setStatus(null);
    try { const r = await fn(); await reload(); if (okText) say(typeof okText === 'function' ? okText(r) : okText); return r; }
    catch (e) { say(e.message || 'Falha ao executar a ação.', false); return null; }
    finally { if (alive.current) setBusy(false); }
  };
  const failures = r => (r?.results || []).filter(x => !x.ok).map(x => x.error);
  const openEntry = e => {
    if (e.type === 'dir') return go(join(cwd, e.name));
    post('/api/files/open', {path: join(cwd, e.name)}).then(() => say(`Abrindo ${e.name}…`)).catch(err => say(err.message, false));
  };
  const reveal = () => post('/api/system/open-nautilus', {path: selected.length === 1 && selected[0].type === 'dir' ? selPaths[0] : cwd}).catch(e => notify?.({title: 'Nautilus', body: e.message}));
  const copy = mode => { if (!selPaths.length) return; setClip({mode, paths: selPaths}); say(`${plural(selPaths.length, 'item', 'itens')} ${mode === 'copy' ? 'copiado(s)' : 'recortado(s)'}.`); };
  const paste = () => clip && run(async () => {
    const r = await post('/api/files/paste', {paths: clip.paths, dest: cwd, mode: clip.mode});
    if (clip.mode === 'move' && !failures(r).length) setClip(null);
    const bad = failures(r); if (bad.length) throw new Error(bad[0] + (bad.length > 1 ? ` (+${bad.length - 1})` : ''));
    return r;
  }, r => `${plural(r.results.length, 'item colado', 'itens colados')}.`);
  const submitDialog = async () => {
    const d = dialog; if (!d) return;
    const name = d.value.trim();
    try {
      setBusy(true);
      if (d.kind === 'mkdir') await post('/api/files/mkdir', {dir: cwd, name});
      else if (d.kind === 'create') await post('/api/files/create', {dir: cwd, name});
      else if (d.kind === 'rename') await post('/api/files/rename', {path: selPaths[0], name});
      else if (d.kind === 'trash') { const r = await post('/api/files/trash', {paths: selPaths}); const bad = failures(r); if (bad.length) throw new Error(bad[0]); }
      setDialog(null); await reload(false);
      if (d.kind === 'mkdir' || d.kind === 'create' || d.kind === 'rename') setSel(new Set([name]));
      say(d.kind === 'trash' ? `${plural(selPaths.length, 'item movido', 'itens movidos')} para a Lixeira.` : d.kind === 'rename' ? 'Renomeado.' : 'Criado.');
    } catch (e) { setDialog(x => x && {...x, error: e.message}); }
    finally { if (alive.current) setBusy(false); }
  };
  const ask = kind => {
    if (kind === 'rename' && selected.length !== 1) return;
    if (kind === 'trash' && !selected.length) return;
    setMenu(null); setDialog({kind, value: kind === 'rename' ? selected[0].name : kind === 'mkdir' ? 'Nova pasta' : kind === 'create' ? 'Novo arquivo.txt' : '', error: ''});
  };

  /* ---------- Seleção e teclado ---------- */
  const pick = (e, i, ev) => {
    if (ev.shiftKey && anchor.current != null) {
      const [a, b] = [Math.min(anchor.current, i), Math.max(anchor.current, i)];
      setSel(new Set(entries.slice(a, b + 1).map(x => x.name)));
    } else if (ev.ctrlKey || ev.metaKey) {
      setSel(s => { const n = new Set(s); n.has(e.name) ? n.delete(e.name) : n.add(e.name); return n; }); anchor.current = i;
    } else { setSel(new Set([e.name])); anchor.current = i; }
  };
  const step = d => {
    if (!entries.length) return;
    const cur = anchor.current ?? (d > 0 ? -1 : entries.length), i = Math.min(entries.length - 1, Math.max(0, cur + d));
    anchor.current = i; setSel(new Set([entries[i].name]));
    requestAnimationFrame(() => rootRef.current?.querySelector('.fm-row.on')?.scrollIntoView({block: 'nearest'}));
  };
  const onKey = e => {
    if (dialog || e.target.closest('input')) return;
    const k = e.key.toLowerCase(), c = e.ctrlKey || e.metaKey;
    if (k === 'enter' && selected[0]) openEntry(selected[0]);
    else if (k === 'f2') ask('rename');
    else if (k === 'delete') ask('trash');
    else if (k === 'backspace' || (e.altKey && k === 'arrowup')) up();
    else if (e.altKey && k === 'arrowleft') back();
    else if (e.altKey && k === 'arrowright') forward();
    else if (k === 'arrowdown') step(1);
    else if (k === 'arrowup') step(-1);
    else if (k === 'f5' || (c && k === 'r')) reload();
    else if (c && k === 'c') copy('copy');
    else if (c && k === 'x') copy('move');
    else if (c && k === 'v') paste();
    else if (c && k === 'a') setSel(new Set(entries.map(x => x.name)));
    else if (c && k === 'h') toggleHidden();
    else if (c && e.shiftKey && k === 'n') ask('mkdir');
    else if (k === 'escape') { setSel(new Set()); setMenu(null); }
    else return;
    e.preventDefault();
  };
  const ctx = (ev, e, i) => {
    ev.preventDefault();
    if (e && !sel.has(e.name)) { setSel(new Set([e.name])); anchor.current = i; }
    const r = rootRef.current.getBoundingClientRect();
    setMenu({x: Math.min(ev.clientX - r.left, r.width - 210), y: Math.min(ev.clientY - r.top, r.height - 290), onItem: !!e});
  };
  const m = fn => () => { setMenu(null); fn(); };

  const totalSize = selected.reduce((n, e) => n + (e.type === 'file' ? e.size : 0), 0);
  const hasSel = selected.length > 0;

  return (
    <div className="fm" ref={rootRef} tabIndex={0} onKeyDown={onKey} onPointerDown={() => setMenu(null)}>
      <aside className="fm-side" aria-label="Locais">
        {places.map(p => { const I = PLACE_ICON[p.id] || HardDrive; return (
          <button key={p.id} className={`fm-place${cwd === p.path ? ' on' : ''}`} onClick={() => go(p.path)} title={p.path}><I size={16}/><span>{p.label}</span></button>); })}
      </aside>
      <section className="fm-main">
        <div className="fm-bar">
          <button disabled={hist.idx <= 0} onClick={back} title="Voltar (Alt+←)" aria-label="Voltar"><ArrowLeft size={15}/></button>
          <button disabled={hist.idx >= hist.stack.length - 1} onClick={forward} title="Avançar (Alt+→)" aria-label="Avançar"><ArrowRight size={15}/></button>
          <button disabled={!data?.parent} onClick={up} title="Pasta acima (Backspace)" aria-label="Pasta acima"><ArrowUp size={15}/></button>
          <input className="fm-path" value={pathInput} spellCheck={false} aria-label="Caminho" onChange={e => setPathInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') go(pathInput.trim() || '~'); else if (e.key === 'Escape') { setPathInput(cwd); e.currentTarget.blur(); } }} onFocus={e => e.target.select()}/>
          <button onClick={() => reload()} title="Atualizar (F5)" aria-label="Atualizar"><RefreshCw size={15} className={loading ? 'spin' : ''}/></button>
          <button className={showHidden ? 'on' : ''} onClick={toggleHidden} title="Mostrar arquivos ocultos (Ctrl+H)" aria-pressed={showHidden} aria-label="Arquivos ocultos">{showHidden ? <Eye size={15}/> : <EyeOff size={15}/>}</button>
        </div>
        <div className="fm-bar fm-actions">
          <button onClick={() => ask('mkdir')} title="Nova pasta (Ctrl+Shift+N)"><FolderPlus size={15}/><span>Nova pasta</span></button>
          <button onClick={() => ask('create')} title="Novo arquivo vazio"><FilePlus size={15}/><span>Novo arquivo</span></button>
          <i/>
          <button disabled={!hasSel} onClick={() => copy('copy')} title="Copiar (Ctrl+C)" aria-label="Copiar"><Copy size={15}/></button>
          <button disabled={!hasSel} onClick={() => copy('move')} title="Recortar (Ctrl+X)" aria-label="Recortar"><Scissors size={15}/></button>
          <button disabled={!clip || busy} onClick={paste} title={clip ? `Colar ${plural(clip.paths.length, 'item', 'itens')} (Ctrl+V)` : 'Colar (Ctrl+V)'} aria-label="Colar"><ClipboardPaste size={15}/></button>
          <button disabled={selected.length !== 1} onClick={() => ask('rename')} title="Renomear (F2)" aria-label="Renomear"><Pencil size={15}/></button>
          <button disabled={!hasSel} onClick={() => ask('trash')} title="Mover para a Lixeira (Delete)" aria-label="Mover para a Lixeira"><Trash2 size={15}/></button>
          <i/>
          <button onClick={reveal} title="Abrir esta pasta no Nautilus"><ExternalLink size={15}/><span>Nautilus</span></button>
        </div>

        <div className="fm-head" aria-hidden="true"><span>Nome</span><span>Tamanho</span><span>Modificado</span></div>
        <div className="fm-list" role="listbox" aria-multiselectable="true" aria-busy={loading} onContextMenu={ev => ctx(ev, null)} onPointerDown={ev => { if (ev.target === ev.currentTarget) setSel(new Set()); }}>
          {error && <p className="fm-msg err" role="alert"><AlertCircle size={14}/> {error}</p>}
          {!error && !loading && entries.length === 0 && <p className="fm-msg">Esta pasta está vazia.</p>}
          {entries.map((e, i) => { const I = iconFor(e); return (
            <div key={e.name} role="option" aria-selected={sel.has(e.name)} className={`fm-row${sel.has(e.name) ? ' on' : ''}${e.hidden ? ' dim' : ''}${clip?.mode === 'move' && clip.paths.includes(join(cwd, e.name)) ? ' cut' : ''}`}
              onClick={ev => pick(e, i, ev)} onDoubleClick={() => openEntry(e)} onContextMenu={ev => { ev.stopPropagation(); ctx(ev, e, i); }}>
              <span className="fm-name"><I size={16} className={e.type === 'dir' ? 'dir' : ''}/>{e.name}{e.link && <Link2 size={11} className="lnk" aria-label="link simbólico"/>}</span>
              <span>{e.type === 'dir' ? '—' : formatBytes(e.size)}</span><span>{fmtDate(e.mtime)}</span>
            </div>); })}
        </div>

        <footer className="fm-status" role="status">
          <span>{data ? `${plural(data.total, 'item', 'itens')}${data.truncated ? ' (lista parcial)' : ''}` : '…'}{hasSel ? ` · ${plural(selected.length, 'selecionado', 'selecionados')}${totalSize ? ` (${formatBytes(totalSize)})` : ''}` : ''}</span>
          {status && <em className={status.ok ? 'ok' : 'err'}>{status.ok ? <Check size={12}/> : <AlertCircle size={12}/>} {status.text}</em>}
        </footer>

        {menu && (
          <div className="fm-ctx" style={{left: Math.max(4, menu.x), top: Math.max(4, menu.y)}} role="menu" onPointerDown={e => e.stopPropagation()}>
            {menu.onItem && <><button onClick={m(() => selected[0] && openEntry(selected[0]))}>Abrir</button><i/></>}
            {menu.onItem && <><button onClick={m(() => copy('copy'))}>Copiar</button><button onClick={m(() => copy('move'))}>Recortar</button></>}
            <button disabled={!clip} onClick={m(paste)}>Colar aqui</button>
            {menu.onItem && <><i/><button disabled={selected.length !== 1} onClick={() => ask('rename')}>Renomear…</button><button onClick={() => ask('trash')}>Mover para a Lixeira</button></>}
            <i/><button onClick={() => ask('mkdir')}>Nova pasta…</button><button onClick={() => ask('create')}>Novo arquivo…</button>
            <i/><button onClick={m(reveal)}>Abrir no Nautilus</button>
          </div>)}

        {dialog && (
          <div className="fm-modal" role="dialog" aria-modal="true" onPointerDown={e => e.stopPropagation()}>
            <form onSubmit={e => { e.preventDefault(); submitDialog(); }}>
              <h3>{{mkdir: 'Nova pasta', create: 'Novo arquivo', rename: 'Renomear', trash: 'Mover para a Lixeira'}[dialog.kind]}</h3>
              {dialog.kind === 'trash'
                ? <p>{selected.length === 1 ? <>“<b>{selected[0].name}</b>” será movido</> : <><b>{selected.length}</b> itens serão movidos</>} para a Lixeira. Você poderá restaurar depois.</p>
                : <input autoFocus value={dialog.value} aria-label="Nome" spellCheck={false} onChange={e => setDialog(d => ({...d, value: e.target.value, error: ''}))}
                    onFocus={e => { const v = e.target.value, dot = dialog.kind === 'rename' ? v.lastIndexOf('.') : -1; e.target.setSelectionRange(0, dot > 0 ? dot : v.length); }}/>}
              {dialog.error && <p className="fm-msg err" role="alert"><AlertCircle size={13}/> {dialog.error}</p>}
              <div className="fm-btns"><button type="button" onClick={() => setDialog(null)}>Cancelar</button>
                <button type="submit" className="primary" disabled={busy || (dialog.kind !== 'trash' && !dialog.value.trim())}>{dialog.kind === 'trash' ? 'Mover' : dialog.kind === 'rename' ? 'Renomear' : 'Criar'}</button></div>
            </form>
          </div>)}
      </section>
    </div>
  );
}
